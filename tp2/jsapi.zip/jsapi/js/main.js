/*
console.log('load');
var url='http://it-ebooks-api.info/v1/search/postgresql';
var array=[];
fetch(url)
    .then(function(Respuesta){
        return Respuesta.json();
    })
    .then(function (datos){
        array=datos.Books;
        console.log(datos);
    })
    .catch(function(error){
        console.log("ERROR: "+error);
    });
    console.log(array);

*/

function handleClick(){
    var url='http://it-ebooks-api.info/v1/search/';
    var texto=document.getElementById('txt').value;
    fetch(url+texto)
        .then(function(Respuesta){
            return Respuesta.json();
        })
        .then(function (datos){
            var html="";
            datos.Books.forEach(function(libro){
                html+=`
                <div class="col-md-4">
                    <div class="thumbnail">
                        <img src="${libro.Image}" alt="${libro.Title}" class="img-thumbnail">
                        <div class="caption">
                            <h3>${libro.Title}</h3>
                            <p>
                            ${libro.Description}
                            </p>
                        </div>
                    </div>
                </div>
                `;
            });//forEach1
            document.getElementById('respuesta').innerHTML=html;
        })
        .catch(function(error){
            console.log("ERROR: "+error);
        }); //fetch
} //handleClick


document.getElementById('btn').addEventListener('click',handleClick);






